# 🔒 Security Improvements for Session Tokens

This guide provides incremental security improvements for session token storage without breaking your existing WhatsApp API Server.

## Current Implementation Status: ✅ Level 1 - Basic Encryption

## 📊 Security Levels Overview

| Level | Security | Implementation Time | Breaking Changes | Recommendation |
|-------|----------|-------------------|------------------|----------------|
| **1** | Good | 5 minutes | No | ✅ **Current** |
| **2** | Better | 30 minutes | No | For production |
| **3** | Best | 1 hour | Minor | Enterprise |
| **4** | Excellent | 2 hours | Yes | High security |

---

## 🔐 Level 1: File Encryption (✅ IMPLEMENTED)

### What's Done:
- ✅ AES-256-CBC encryption for token storage
- ✅ Automatic migration from plain JSON
- ✅ File permissions set to 600 (owner only)
- ✅ Backward compatibility maintained

### Setup:
1. Generate a secure encryption key:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

2. Add to your `.env` file:
   ```env
   TOKEN_ENCRYPTION_KEY=your_generated_64_character_hex_key_here
   ```

3. Restart your server - tokens will be automatically encrypted!

### How it works:
- Tokens are encrypted using AES-256-CBC
- Each encryption uses a random IV (Initialization Vector)
- Encrypted file: `session_tokens.enc`
- Old `session_tokens.json` is automatically deleted

---

## 🔐 Level 2: Token Hashing with Salt (Better Security)

### Why upgrade?
- Tokens in dashboard are still visible
- If encryption key is compromised, all tokens are exposed
- No token rotation mechanism

### Implementation:

```javascript
// Add to index.js after crypto import
const TOKEN_SALT = process.env.TOKEN_SALT || crypto.randomBytes(16).toString('hex');

// Enhanced token generation
function generateSecureToken() {
    const rawToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto
        .createHash('sha256')
        .update(rawToken + TOKEN_SALT)
        .digest('hex');
    
    return {
        raw: rawToken,        // Give to user
        hashed: hashedToken   // Store in file
    };
}

// Update createSession function
async function createSession(sessionId) {
    if (sessions.has(sessionId)) {
        throw new Error('Session already exists');
    }
    
    const { raw, hashed } = generateSecureToken();
    sessionTokens.set(sessionId, hashed);  // Store hash
    saveTokens();
    
    sessions.set(sessionId, { 
        sessionId: sessionId, 
        status: 'CREATING', 
        detail: 'Session is being created.' 
    });
    
    connectToWhatsApp(sessionId);
    return { 
        status: 'success', 
        message: `Session ${sessionId} created.`, 
        token: raw  // Return raw token (only shown once!)
    };
}

// Update token validation
const validateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ status: 'error', message: 'No token provided' });
    }
    
    const sessionId = req.query.sessionId || req.body.sessionId || req.params.sessionId;
    if (sessionId) {
        const storedHash = sessionTokens.get(sessionId);
        const providedHash = crypto
            .createHash('sha256')
            .update(token + TOKEN_SALT)
            .digest('hex');
            
        if (storedHash && providedHash === storedHash) {
            return next();
        }
    }
    
    return res.status(403).json({ status: 'error', message: 'Invalid token' });
};
```

---

## 🔐 Level 3: JWT Tokens with Expiration (Industry Standard)

### Why upgrade?
- Token expiration for better security
- Token refresh mechanism
- Stateless authentication
- Can include metadata (permissions, scopes)

### Installation:
```bash
npm install jsonwebtoken
```

### Implementation:

```javascript
const jwt = require('jsonwebtoken');

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

// Generate JWT token
function generateJWT(sessionId) {
    const payload = {
        sessionId,
        createdAt: Date.now(),
        permissions: ['send_message', 'manage_session']
    };
    
    return jwt.sign(payload, JWT_SECRET, { 
        expiresIn: JWT_EXPIRES_IN,
        issuer: 'whatsapp-api-server'
    });
}

// Validate JWT token
const validateJWT = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ status: 'error', message: 'No token provided' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.tokenData = decoded;
        
        // Check if token is for the requested session
        const sessionId = req.query.sessionId || req.body.sessionId || req.params.sessionId;
        if (sessionId && decoded.sessionId !== sessionId) {
            return res.status(403).json({ status: 'error', message: 'Token not valid for this session' });
        }
        
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ status: 'error', message: 'Token expired' });
        }
        return res.status(403).json({ status: 'error', message: 'Invalid token' });
    }
};

// Token refresh endpoint
router.post('/token/refresh', validateJWT, (req, res) => {
    const newToken = generateJWT(req.tokenData.sessionId);
    res.json({ token: newToken });
});
```

---

## 🔐 Level 4: SQLite Database with Encryption (Best Practice)

### Why upgrade?
- Proper database for token management
- Query capabilities
- Audit trail
- Better performance at scale

### Installation:
```bash
npm install sqlite3 bcrypt
```

### Implementation:

```javascript
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');

// Initialize database
const db = new sqlite3.Database('./tokens.db');

// Create tables
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS session_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT UNIQUE NOT NULL,
            token_hash TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_used DATETIME,
            expires_at DATETIME,
            ip_address TEXT,
            user_agent TEXT
        )
    `);
    
    db.run(`
        CREATE TABLE IF NOT EXISTS token_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            action TEXT NOT NULL,
            ip_address TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            details TEXT
        )
    `);
});

// Token management with database
class TokenManager {
    async createToken(sessionId, req) {
        const token = crypto.randomBytes(32).toString('hex');
        const hash = await bcrypt.hash(token, 10);
        
        return new Promise((resolve, reject) => {
            db.run(
                `INSERT INTO session_tokens (session_id, token_hash, expires_at, ip_address, user_agent) 
                 VALUES (?, ?, datetime('now', '+30 days'), ?, ?)`,
                [sessionId, hash, req.ip, req.headers['user-agent']],
                function(err) {
                    if (err) reject(err);
                    else {
                        this.logAction(sessionId, 'created', req.ip);
                        resolve(token);
                    }
                }
            );
        });
    }
    
    async validateToken(token, sessionId) {
        return new Promise((resolve, reject) => {
            db.get(
                `SELECT * FROM session_tokens WHERE session_id = ? AND expires_at > datetime('now')`,
                [sessionId],
                async (err, row) => {
                    if (err) reject(err);
                    else if (!row) resolve(false);
                    else {
                        const valid = await bcrypt.compare(token, row.token_hash);
                        if (valid) {
                            // Update last used
                            db.run(
                                `UPDATE session_tokens SET last_used = datetime('now') WHERE id = ?`,
                                [row.id]
                            );
                        }
                        resolve(valid);
                    }
                }
            );
        });
    }
    
    logAction(sessionId, action, ip, details = null) {
        db.run(
            `INSERT INTO token_logs (session_id, action, ip_address, details) VALUES (?, ?, ?, ?)`,
            [sessionId, action, ip, details]
        );
    }
}

const tokenManager = new TokenManager();
```

---

## 🛡️ Additional Security Recommendations

### 1. **Environment Security**
```bash
# Generate all required keys
node -e "
console.log('TOKEN_ENCRYPTION_KEY=' + require('crypto').randomBytes(32).toString('hex'));
console.log('TOKEN_SALT=' + require('crypto').randomBytes(16).toString('hex'));
console.log('JWT_SECRET=' + require('crypto').randomBytes(64).toString('hex'));
"
```

### 2. **Token Display Security**
Update `dashboard.html` to hide tokens:

```javascript
// In dashboard.html, update token display
const tokenEl = document.getElementById(`token-${session.sessionId}`);
tokenEl.value = session.token ? '••••••••••••••••' : 'N/A';
tokenEl.dataset.token = session.token; // Store actual token in data attribute

// Add reveal button
<button class="btn btn-sm" onclick="toggleTokenVisibility('${session.sessionId}')">
    <i class="bi bi-eye"></i>
</button>
```

### 3. **Rate Limiting per Token**
```javascript
const tokenRateLimiter = new Map();

function checkTokenRateLimit(token) {
    const now = Date.now();
    const limit = tokenRateLimiter.get(token) || { count: 0, resetAt: now + 60000 };
    
    if (now > limit.resetAt) {
        limit.count = 1;
        limit.resetAt = now + 60000;
    } else {
        limit.count++;
    }
    
    tokenRateLimiter.set(token, limit);
    return limit.count <= 30; // 30 requests per minute
}
```

### 4. **Token Rotation**
```javascript
// Automatic token rotation every 30 days
setInterval(() => {
    sessions.forEach((session, sessionId) => {
        if (session.status === 'CONNECTED') {
            const newToken = generateSecureToken();
            sessionTokens.set(sessionId, newToken.hashed);
            saveTokens();
            
            // Notify via webhook about token rotation
            postToWebhook({
                event: 'token-rotated',
                sessionId,
                message: 'Token has been rotated. Please update your integration.'
            });
        }
    });
}, 30 * 24 * 60 * 60 * 1000); // 30 days
```

---

## 🚀 Migration Guide

### From Level 1 to Level 2:
1. Add `TOKEN_SALT` to `.env`
2. Update token generation and validation functions
3. Run migration script to hash existing tokens
4. Update dashboard to handle token visibility

### From Level 2 to Level 3:
1. Install `jsonwebtoken`
2. Add `JWT_SECRET` to `.env`
3. Replace token generation with JWT
4. Update all validation middleware
5. Add token refresh endpoint

### From Level 3 to Level 4:
1. Install `sqlite3` and `bcrypt`
2. Create database schema
3. Migrate existing tokens to database
4. Update all token operations
5. Add audit logging

---

## 📊 Security Comparison

| Feature | Plain JSON | Level 1 | Level 2 | Level 3 | Level 4 |
|---------|-----------|---------|---------|---------|---------|
| Encryption at rest | ❌ | ✅ | ✅ | ✅ | ✅ |
| Token hashing | ❌ | ❌ | ✅ | ✅ | ✅ |
| Token expiration | ❌ | ❌ | ❌ | ✅ | ✅ |
| Audit trail | ❌ | ❌ | ❌ | ❌ | ✅ |
| Rate limiting | ❌ | ❌ | ✅ | ✅ | ✅ |
| Token rotation | ❌ | ❌ | Manual | Auto | Auto |
| Performance impact | None | Minimal | Minimal | Low | Low |

---

## 🔍 Testing Your Security

### 1. Test Encryption (Level 1):
```bash
# Check if tokens are encrypted
cat session_tokens.enc
# Should see encrypted gibberish, not JSON
```

### 2. Test Token Validation:
```bash
# Valid token
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:3000/api/v1/sessions

# Invalid token
curl -H "Authorization: Bearer INVALID_TOKEN" http://localhost:3000/api/v1/sessions
# Should return 403 Forbidden
```

### 3. Security Audit Checklist:
- [ ] Encryption key in `.env` (not in code)
- [ ] `.env` file not in git repository
- [ ] `session_tokens.enc` not in git repository
- [ ] File permissions set correctly (600)
- [ ] Tokens not visible in logs
- [ ] HTTPS enabled in production
- [ ] Rate limiting active
- [ ] Token expiration implemented

---

## 📞 Support

If you need help implementing any security level, create an issue with:
1. Current security level
2. Target security level
3. Any errors encountered
4. Your use case requirements 

---

# 🚨 Session Creation Rate Limiting
✅ Email notifications for backup codes

---

## 🔐 Session Creation Security

### Current Risk: Unauthenticated POST /sessions

The `POST /api/v1/sessions` endpoint currently allows anyone to create unlimited sessions without authentication, posing significant security risks.

### ✅ Implemented Solution: Master API Key with Admin Bypass

The system now requires a master API key for session creation via API, while allowing authenticated admin users to create sessions from the dashboard without the key.

**Access Methods:**
1. **Admin Dashboard**: Logged-in admins can create sessions without any API key
2. **API Access**: External API calls require the `X-Master-Key` header

### Implementation Options:

#### Option 1: Master API Key (Recommended - No Breaking Changes)
Add a master API key requirement for session creation while keeping existing session tokens working.

```javascript
// In .env file
MASTER_API_KEY=your-secure-master-key-here

// In api_v1.js - modify the POST /sessions endpoint
router.post('/sessions', async (req, res) => {
    // Add master key check
    const masterKey = req.headers['x-master-key'];
    if (masterKey !== process.env.MASTER_API_KEY) {
        return res.status(401).json({ 
            status: 'error', 
            message: 'Master API key required for session creation' 
        });
    }
    
    // ... existing code continues
});
```

**Pros:**
- No breaking changes for existing users
- Easy to implement
- Can share master key with trusted users only

#### Option 2: Session Limits & Cleanup
Implement resource limits without authentication changes.

```javascript
// Add to index.js
const MAX_SESSIONS = parseInt(process.env.MAX_SESSIONS) || 10;
const SESSION_TIMEOUT_HOURS = parseInt(process.env.SESSION_TIMEOUT_HOURS) || 24;

async function createSession(sessionId) {
    // Check session limit
    if (sessions.size >= MAX_SESSIONS) {
        throw new Error(`Maximum session limit (${MAX_SESSIONS}) reached`);
    }
    
    // ... existing code
    
    // Add auto-cleanup after timeout
    setTimeout(() => {
        if (sessions.get(sessionId)?.status !== 'CONNECTED') {
            deleteSession(sessionId);
            log(`Auto-deleted inactive session: ${sessionId}`, 'SYSTEM');
        }
    }, SESSION_TIMEOUT_HOURS * 60 * 60 * 1000);
}
```

#### Option 3: IP-Based Rate Limiting
Enhanced rate limiting per IP address.

```javascript
// Add more aggressive rate limiting for session creation
const sessionCreationLimiter = rateLimit({
    windowMs: 24 * 60 * 60 * 1000, // 24 hours
    max: 3, // Max 3 sessions per IP per day
    skipSuccessfulRequests: false,
    keyGenerator: (req) => req.ip,
    handler: (req, res) => {
        res.status(429).json({
            status: 'error',
            message: 'Too many sessions created from this IP. Try again tomorrow.'
        });
    }
});

router.post('/sessions', sessionCreationLimiter, async (req, res) => {
    // ... existing code
});
```

#### Option 4: Session Approval Workflow
Require admin approval for new sessions.

```javascript
// Add pending sessions concept
const pendingSessions = new Map();

router.post('/sessions', async (req, res) => {
    const { sessionId, requestReason, email } = req.body;
    
    // Store as pending
    pendingSessions.set(sessionId, {
        sessionId,
        requestReason,
        email,
        requestedAt: new Date(),
        ip: req.ip
    });
    
    // Notify admin (via webhook or email)
    notifyAdmin(`New session request: ${sessionId}`);
    
    res.status(202).json({
        status: 'pending',
        message: 'Session request submitted. Awaiting admin approval.'
    });
});

// Admin approval endpoint
router.post('/sessions/:sessionId/approve', requireAdminAuth, async (req, res) => {
    const { sessionId } = req.params;
    const pending = pendingSessions.get(sessionId);
    
    if (!pending) {
        return res.status(404).json({ error: 'Pending session not found' });
    }
    
    await createSession(sessionId);
    pendingSessions.delete(sessionId);
    
    res.json({ status: 'success', message: 'Session approved and created' });
});
```

### Recommended Implementation Strategy:

1. **Immediate (5 minutes)**: Implement Option 1 (Master API Key)
2. **Short-term (1 hour)**: Add Option 2 (Session Limits)
3. **Medium-term (1 day)**: Implement Option 3 (IP Rate Limiting)
4. **Long-term (optional)**: Consider Option 4 for enterprise use

### Environment Variables to Add:
```bash
# Master API key for session creation
MASTER_API_KEY=generate-a-secure-key-here

# Maximum number of concurrent sessions
MAX_SESSIONS=10

# Auto-delete inactive sessions after X hours
SESSION_TIMEOUT_HOURS=24

# Sessions per IP per day
MAX_SESSIONS_PER_IP=3
```

### Migration Guide:
1. Add `MASTER_API_KEY` to your `.env` file
2. Update your session creation calls to include the header:
   ```bash
   curl -X POST "http://localhost:3000/api/v1/sessions" \
   -H "X-Master-Key: your-master-key" \
   -H "Content-Type: application/json" \
   -d '{"sessionId": "mySession"}'
   ```
3. Existing sessions and their tokens continue to work normally
4. Only new session creation requires the master key 