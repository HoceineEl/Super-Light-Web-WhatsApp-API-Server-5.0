# WhatsApp API Test Script

This Python script tests the WhatsApp API Server functionality by sending messages to the specified number.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Make sure your WhatsApp API Server is running:
```bash
npm start
```

3. Ensure you have at least one connected session in the admin dashboard.

## Configuration

The script is pre-configured with:
- **API URL**: http://localhost:3000/api/v1
- **Master API Key**: From your .env file
- **Target Number**: 6283865213518

## Usage

Run the script:
```bash
python test_whatsapp_api.py
```

The script will:
1. List all available sessions
2. Show only connected sessions
3. Let you select which session to use
4. Provide an interactive menu to:
   - Send text messages
   - Send images with captions
   - Send combo messages (text + image + document)
   - Run all tests sequentially

## Features

- ✅ Colorful terminal output
- ✅ Interactive session selection
- ✅ Multiple message types support
- ✅ Error handling and validation
- ✅ Real-time status updates

## Example Messages

The script sends test messages with timestamps to help identify each test run.

### Text Message
```
🤖 Test message from Python script at 2024-01-15 10:30:45
```

### Image Message
- Random image from Lorem Picsum
- Caption with timestamp

### Document Message
- Sample PDF document
- Custom filename

## Troubleshooting

If you see "No connected sessions found!":
1. Open the admin dashboard: http://localhost:3000/admin
2. Login with password: ChangeMe123!
3. Create a new session
4. Scan the QR code with WhatsApp
5. Wait for "CONNECTED" status
6. Run the script again 