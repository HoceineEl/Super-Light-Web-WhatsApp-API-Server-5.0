# WhatsApp Bulk Campaign Feature - Implementation Plan

## Overview
Implement a MailChimp-like bulk WhatsApp messaging campaign feature that allows users to upload CSV files, create reusable message templates with placeholders, and track delivery status.

## Feature Requirements

### 1. Core Functionality
- **CSV Upload & Parsing**: Accept CSV files with contact information
- **Campaign Management**: Create, edit, delete, and reuse campaigns
- **Message Composition**: Rich text editor (QuillJS) with placeholder support
- **Bulk Sending**: Send messages to all contacts in the CSV
- **Status Tracking**: Track delivery status for each message
- **Role-Based Access**: Available for both admin and user roles
- **File-Based Storage**: Store campaigns as JSON files (no database)

### 2. CSV Format Requirements
```csv
WhatsApp Number,Name,Job Title,Company Name,Custom Field 1,Custom Field 2
6281234567890,Adi Pratama,IT Manager,PT Sukses Makmur,Value1,Value2
6289876543210,Budi Santoso,Data Engineer,Inovasi Digital,Value1,Value2
```

### 3. Campaign Data Structure
```json
{
  "id": "campaign_1234567890",
  "name": "W.Media Awards 2025 Campaign #1",
  "createdBy": "user@example.com",
  "createdAt": "2025-07-15T10:00:00Z",
  "scheduledAt": "2025-07-16T09:00:00Z",
  "status": "scheduled|sending|completed|paused",
  "sessionId": "mySession",
  "message": {
    "type": "text|image|document",
    "content": "<p>Hi {{Name}},</p><p>We're excited to invite you...</p>",
    "mediaUrl": "optional_media_url",
    "mediaCaption": "optional_caption_with_{{placeholders}}"
  },
  "recipients": [
    {
      "number": "6281234567890",
      "name": "Adi Pratama",
      "jobTitle": "IT Manager",
      "companyName": "PT Sukses Makmur",
      "customFields": {},
      "status": "pending|sending|sent|failed",
      "sentAt": null,
      "error": null
    }
  ],
  "statistics": {
    "total": 100,
    "sent": 75,
    "failed": 25,
    "pending": 0
  }
}
```

## Implementation Components

### 1. Frontend Components

#### A. Campaign List Page (`/admin/campaigns.html`)
- Display all campaigns in cards/table format
- Show campaign status, stats, and actions
- Filter by status, date, creator
- Actions: View, Edit, Clone, Delete, Send/Pause

#### B. Campaign Creator/Editor Modal/Page
- **Step 1: Basic Info**
  - Campaign name
  - Select WhatsApp session
  - Schedule send time (optional)
  
- **Step 2: Upload Recipients**
  - CSV file upload with drag & drop
  - Preview uploaded data in table
  - Validate phone numbers
  - Show total recipients count
  
- **Step 3: Compose Message**
  - QuillJS rich text editor
  - Placeholder dropdown (insert {{Name}}, {{Company}}, etc.)
  - Preview with sample data
  - Support for text/image/document messages
  
- **Step 4: Review & Send**
  - Show campaign summary
  - Preview final message with real data
  - Confirm and send/schedule

#### C. Campaign Detail View
- Campaign info card
- Recipients table with search/filter
- Real-time status updates via WebSocket
- Export results to CSV
- Retry failed messages

### 2. Backend Implementation

#### A. New API Endpoints

```javascript
// Campaign Management
POST   /api/v1/campaigns              // Create new campaign
GET    /api/v1/campaigns              // List all campaigns
GET    /api/v1/campaigns/:id          // Get campaign details
PUT    /api/v1/campaigns/:id          // Update campaign
DELETE /api/v1/campaigns/:id          // Delete campaign
POST   /api/v1/campaigns/:id/clone    // Clone campaign
POST   /api/v1/campaigns/:id/send     // Start sending campaign
POST   /api/v1/campaigns/:id/pause    // Pause campaign
POST   /api/v1/campaigns/:id/retry    // Retry failed messages

// CSV Processing
POST   /api/v1/campaigns/preview-csv  // Upload and preview CSV
```

#### B. Storage Structure
```
/campaigns/
  ├── campaign_1234567890.json
  ├── campaign_1234567891.json
  └── campaign_1234567892.json
  
/campaign_media/
  ├── campaign_1234567890/
  │   └── image.jpg
  └── campaign_1234567891/
      └── document.pdf
```

#### C. Core Functions

1. **CSV Parser**
   - Use `csv-parse` library
   - Validate phone numbers
   - Handle various CSV formats
   - Support custom field mapping

2. **Template Engine**
   - Replace placeholders with actual values
   - Support nested placeholders
   - Handle missing values gracefully

3. **Message Queue System**
   - Process messages in batches
   - Rate limiting (configurable delay between messages)
   - Retry mechanism for failed messages
   - Progress tracking

4. **Status Updates**
   - WebSocket real-time updates
   - Periodic status saves to JSON
   - Activity logging integration

### 3. UI/UX Design Elements

#### A. Campaign Card Component
```html
<div class="campaign-card">
  <div class="campaign-header">
    <h3>Campaign Name</h3>
    <span class="campaign-status">Scheduled</span>
  </div>
  <div class="campaign-stats">
    <div class="stat">
      <span class="stat-value">100</span>
      <span class="stat-label">Total</span>
    </div>
    <div class="stat">
      <span class="stat-value">75</span>
      <span class="stat-label">Sent</span>
    </div>
    <div class="stat">
      <span class="stat-value">25</span>
      <span class="stat-label">Failed</span>
    </div>
  </div>
  <div class="campaign-actions">
    <button>View Details</button>
    <button>Clone</button>
    <button>Delete</button>
  </div>
</div>
```

#### B. Rich Text Editor Integration
- QuillJS toolbar with formatting options
- Custom button for placeholder insertion
- Live preview panel
- Support for emojis

#### C. Progress Indicator
- Real-time progress bar
- Current recipient being processed
- Estimated time remaining
- Pause/Resume controls

### 4. Security & Permissions

1. **Access Control**
   - Users can only view/edit their own campaigns
   - Admins can view/edit all campaigns
   - Activity logging for all operations

2. **File Upload Security**
   - Validate file type (CSV only)
   - Size limits (e.g., max 10MB)
   - Scan for malicious content
   - Sanitize file names

3. **Rate Limiting**
   - Configurable delay between messages
   - Daily/hourly limits per user
   - Prevent WhatsApp bans

### 5. Advanced Features (Future)

1. **A/B Testing**
   - Send different messages to segments
   - Track performance metrics

2. **Analytics Dashboard**
   - Campaign performance charts
   - Delivery rate trends
   - Best time to send analysis

3. **Contact Management**
   - Save frequently used contact lists
   - Contact segmentation/tags

4. **Webhook Integration**
   - Trigger campaigns via API
   - Export results to external systems

## Implementation Steps

### Phase 1: Basic Infrastructure (Week 1)
1. Create campaign storage system
2. Implement CSV upload and parsing
3. Build campaign CRUD API endpoints
4. Create basic campaign list UI

### Phase 2: Message Composition (Week 2)
1. Integrate QuillJS editor
2. Implement placeholder system
3. Add message preview functionality
4. Support multiple message types

### Phase 3: Sending Engine (Week 3)
1. Build message queue system
2. Implement bulk sending logic
3. Add status tracking
4. Create progress indicators

### Phase 4: UI Polish & Testing (Week 4)
1. Responsive design improvements
2. Real-time updates via WebSocket
3. Error handling and validation
4. User testing and bug fixes

## Technical Considerations

### 1. Performance
- Pagination for large recipient lists
- Lazy loading for campaign list
- Efficient CSV parsing for large files
- Background processing for sending

### 2. Reliability
- Auto-save drafts
- Resume interrupted campaigns
- Detailed error logging
- Backup campaign data

### 3. User Experience
- Intuitive wizard-style interface
- Clear status indicators
- Helpful error messages
- Keyboard shortcuts

### 4. Monitoring
- Campaign performance metrics
- System health checks
- Error rate monitoring
- User activity tracking

## Dependencies

### NPM Packages to Add
```json
{
  "csv-parse": "^5.5.0",
  "quill": "^1.3.7",
  "date-fns": "^2.30.0",
  "sanitize-html": "^2.11.0"
}
```

### Frontend Libraries
- QuillJS for rich text editing
- Papa Parse for client-side CSV parsing
- Chart.js for analytics (future)

## Success Metrics

1. **Functionality**
   - Successfully send bulk messages
   - < 1% error rate for valid numbers
   - Real-time status updates

2. **Performance**
   - Process 1000 messages in < 5 minutes
   - CSV upload < 3 seconds for 10k rows
   - UI remains responsive during sending

3. **User Satisfaction**
   - Intuitive interface requiring minimal training
   - Positive user feedback
   - Increased API usage

## Risk Mitigation

1. **WhatsApp Bans**
   - Implement rate limiting
   - Add delay between messages
   - Monitor for ban indicators

2. **Data Loss**
   - Regular backups of campaigns
   - Transaction logs
   - Atomic file operations

3. **Performance Issues**
   - Implement pagination
   - Use worker threads for processing
   - Cache frequently accessed data

## Conclusion

This WhatsApp bulk campaign feature will provide users with a powerful tool for mass communication while maintaining the simplicity and reliability of the existing system. The file-based approach keeps the architecture simple while providing all necessary functionality for effective campaign management. 