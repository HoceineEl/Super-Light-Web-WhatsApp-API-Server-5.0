#!/usr/bin/env node

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

console.log('🔒 Token Encryption Test Script\n');

// Generate test encryption key
const TEST_KEY = crypto.randomBytes(32).toString('hex');
console.log('1. Generated test encryption key:', TEST_KEY.substring(0, 20) + '...');

// Test encryption functions
function encrypt(text, key) {
    const algorithm = 'aes-256-cbc';
    const keyBuffer = Buffer.from(key.slice(0, 64), 'hex');
    const iv = crypto.randomBytes(16);
    
    const cipher = crypto.createCipheriv(algorithm, keyBuffer, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    return iv.toString('hex') + ':' + encrypted;
}

function decrypt(text, key) {
    const algorithm = 'aes-256-cbc';
    const keyBuffer = Buffer.from(key.slice(0, 64), 'hex');
    
    const parts = text.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encryptedText = parts[1];
    
    const decipher = crypto.createDecipheriv(algorithm, keyBuffer, iv);
    let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
}

// Test data
const testTokens = {
    "session1": "token_abc123_very_secret",
    "session2": "token_xyz789_super_secret"
};

console.log('\n2. Original tokens:', JSON.stringify(testTokens, null, 2));

// Encrypt
const jsonString = JSON.stringify(testTokens, null, 2);
const encrypted = encrypt(jsonString, TEST_KEY);
console.log('\n3. Encrypted data:', encrypted.substring(0, 50) + '...');

// Decrypt
const decrypted = decrypt(encrypted, TEST_KEY);
const parsedTokens = JSON.parse(decrypted);
console.log('\n4. Decrypted tokens:', JSON.stringify(parsedTokens, null, 2));

// Verify
const success = JSON.stringify(testTokens) === JSON.stringify(parsedTokens);
console.log('\n5. Test result:', success ? '✅ SUCCESS' : '❌ FAILED');

// Check if actual encrypted file exists
const ENCRYPTED_FILE = path.join(__dirname, 'session_tokens.enc');
if (fs.existsSync(ENCRYPTED_FILE)) {
    console.log('\n6. Found encrypted tokens file!');
    console.log('   File size:', fs.statSync(ENCRYPTED_FILE).size, 'bytes');
    console.log('   File permissions:', (fs.statSync(ENCRYPTED_FILE).mode & parseInt('777', 8)).toString(8));
    
    // Try to read with wrong key (should fail)
    try {
        const wrongKey = crypto.randomBytes(32).toString('hex');
        const encryptedContent = fs.readFileSync(ENCRYPTED_FILE, 'utf-8');
        decrypt(encryptedContent, wrongKey);
        console.log('   ❌ WARNING: File can be decrypted with wrong key!');
    } catch (e) {
        console.log('   ✅ File cannot be decrypted with wrong key (good!)');
    }
} else {
    console.log('\n6. No encrypted tokens file found yet.');
    console.log('   Run your server to create one.');
}

console.log('\n7. Security recommendations:');
console.log('   - Store TOKEN_ENCRYPTION_KEY in .env file');
console.log('   - Never commit .env or session_tokens.enc to git');
console.log('   - Use different keys for different environments');
console.log('   - Rotate keys periodically');

console.log('\n✨ Test complete!'); 