# WhatsApp API Server - Code Reorganization Plan

## Overview
This document outlines a strategic plan to reorganize the WhatsApp API Server codebase for better maintainability, scalability, and code organization. The goal is to split the monolithic files into smaller, focused modules without affecting functionality.

## Current Issues
1. **index.js** - 483 lines containing mixed concerns (server setup, WhatsApp logic, API routes, logging, etc.)
2. **dashboard.html** - 1747 lines with inline JavaScript, making it hard to maintain
3. **api_v1.js** - Contains all API logic in a single file
4. No clear separation of concerns or modular structure

## Proposed Directory Structure

```
Super-Light-Web-WhatsApp-API-Server/
├── src/
│   ├── controllers/        # Business logic controllers
│   │   ├── sessionController.js
│   │   ├── messageController.js
│   │   ├── adminController.js
│   │   └── webhookController.js
│   ├── services/          # Core services
│   │   ├── whatsappService.js
│   │   ├── webhookService.js
│   │   ├── logService.js
│   │   └── mediaService.js
│   ├── middleware/        # Express middleware
│   │   ├── authMiddleware.js
│   │   ├── securityMiddleware.js
│   │   └── validationMiddleware.js
│   ├── routes/           # Route definitions
│   │   ├── apiRoutes.js
│   │   ├── adminRoutes.js
│   │   ├── sessionRoutes.js
│   │   └── legacyRoutes.js
│   ├── utils/            # Utility functions
│   │   ├── logger.js
│   │   ├── tokenManager.js
│   │   ├── fileManager.js
│   │   └── constants.js
│   └── models/           # Data models/schemas
│       └── session.js
├── admin/                # Admin dashboard files
│   ├── js/              # Extracted JavaScript
│   │   ├── dashboard.js
│   │   ├── sessionManager.js
│   │   ├── apiControl.js
│   │   ├── logViewer.js
│   │   └── utils.js
│   ├── css/             # Extracted styles
│   │   └── dashboard.css
│   ├── components/      # HTML components
│   │   ├── sessionCard.js
│   │   ├── logEntry.js
│   │   └── apiTester.js
│   ├── dashboard.html   # Simplified HTML
│   └── login.html
├── config/              # Configuration files
│   ├── default.js
│   └── production.js
├── public/              # Static assets
│   └── media/
├── tests/               # Test files
├── app.js              # Main application entry
└── server.js           # Server initialization

```

## Implementation Phases

### Phase 1: Core Infrastructure Setup
1. Create directory structure
2. Set up configuration management
3. Extract utility functions (logger, token manager, file manager)
4. Create base middleware modules

### Phase 2: Backend Modularization
1. Extract WhatsApp service logic from index.js
2. Separate session management into sessionController
3. Move message handling to messageController
4. Extract webhook logic to webhookService
5. Modularize route definitions

### Phase 3: Frontend Reorganization
1. Extract JavaScript from dashboard.html into separate modules:
   - Session management UI logic
   - API control center logic
   - System log viewer logic
   - Utility functions
2. Extract CSS into separate stylesheet
3. Create reusable component modules
4. Implement module loader in dashboard.html

### Phase 4: Testing and Validation
1. Ensure all functionality remains intact
2. Test all API endpoints
3. Verify WebSocket connections
4. Test admin dashboard features
5. Validate file uploads and media serving

## Module Breakdown

### Backend Modules

#### 1. **server.js** (New main entry point)
- Express server setup
- Middleware configuration
- Route mounting
- WebSocket server initialization

#### 2. **src/services/whatsappService.js**
- WhatsApp connection logic
- Message sending/receiving
- QR code generation
- Session state management

#### 3. **src/services/logService.js**
- System logging functionality
- Log file management
- Log rotation
- Export functionality

#### 4. **src/controllers/sessionController.js**
- Create/delete sessions
- Get session details
- QR code requests
- Session state updates

#### 5. **src/controllers/messageController.js**
- Send messages (text, image, document)
- Message validation
- Media handling

#### 6. **src/utils/tokenManager.js**
- Token generation
- Token persistence
- Token validation

### Frontend Modules

#### 1. **admin/js/dashboard.js** (Main dashboard controller)
- Page initialization
- Module coordination
- Theme management
- WebSocket connection

#### 2. **admin/js/sessionManager.js**
- Session card creation/updates
- Session CRUD operations
- QR code display
- Token management UI

#### 3. **admin/js/apiControl.js**
- API testing interface
- Request building
- Response display
- cURL example generation

#### 4. **admin/js/logViewer.js**
- System log display
- Log filtering/searching
- Bulk operations
- Export functionality

#### 5. **admin/js/utils.js**
- DOM manipulation helpers
- Sanitization functions
- Clipboard operations
- Toast notifications

## Migration Strategy

### Step 1: Create Module Structure
```bash
mkdir -p src/{controllers,services,middleware,routes,utils,models}
mkdir -p admin/{js,css,components}
mkdir -p config
```

### Step 2: Extract Without Breaking
1. Create new modules with exported functions
2. Import modules in original files
3. Gradually move functionality
4. Test after each extraction

### Step 3: Update Import Paths
1. Update require/import statements
2. Ensure all dependencies are resolved
3. Update package.json if needed

### Step 4: Clean Up
1. Remove redundant code
2. Update documentation
3. Add JSDoc comments
4. Create module documentation

## Benefits

1. **Maintainability**: Easier to locate and modify specific functionality
2. **Testability**: Individual modules can be unit tested
3. **Scalability**: New features can be added without affecting existing code
4. **Team Collaboration**: Multiple developers can work on different modules
5. **Code Reusability**: Modules can be reused across the application
6. **Performance**: Potential for lazy loading and optimization

## Risk Mitigation

1. **Backup Current Code**: Create a backup branch before starting
2. **Incremental Changes**: Make small, testable changes
3. **Continuous Testing**: Test after each module extraction
4. **Documentation**: Document changes and module interfaces
5. **Rollback Plan**: Keep the ability to revert changes if needed

## Success Criteria

1. All existing functionality works as before
2. Code is organized into logical modules
3. No duplicate code across modules
4. Clear separation of concerns
5. Improved development experience
6. Easier onboarding for new developers

## Timeline

- **Week 1**: Phase 1 - Core Infrastructure
- **Week 2**: Phase 2 - Backend Modularization
- **Week 3**: Phase 3 - Frontend Reorganization
- **Week 4**: Phase 4 - Testing and Documentation

## Next Steps

1. Review and approve this plan
2. Create feature branch for reorganization
3. Begin with Phase 1 implementation
4. Regular testing and validation
5. Documentation updates 