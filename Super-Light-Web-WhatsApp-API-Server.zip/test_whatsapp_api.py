#!/usr/bin/env python3
"""
WhatsApp API Test Script
Tests sending messages through the WhatsApp API Server
"""

import requests
import json
import sys
from datetime import datetime

# Configuration
API_BASE_URL = "http://localhost:3000/api/v1"
MASTER_API_KEY = "7nr13jd5v8ewe6q7CKkr7vbl2z7GxBkJAXFvceNNkTg="
RECIPIENT_NUMBER = "6283865213518"
1

# Colors for terminal output
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

def print_header(text):
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{text.center(60)}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.ENDC}\n")

def print_success(text):
    print(f"{Colors.OKGREEN}✓ {text}{Colors.ENDC}")

def print_error(text):
    print(f"{Colors.FAIL}✗ {text}{Colors.ENDC}")

def print_info(text):
    print(f"{Colors.OKCYAN}ℹ {text}{Colors.ENDC}")

def print_warning(text):
    print(f"{Colors.WARNING}⚠ {text}{Colors.ENDC}")

def list_sessions():
    """List all available sessions"""
    print_header("LISTING ALL SESSIONS")
    
    try:
        response = requests.get(f"{API_BASE_URL}/sessions")
        response.raise_for_status()
        
        sessions = response.json()
        
        if not sessions:
            print_warning("No sessions found!")
            return None
        
        print(f"Found {len(sessions)} session(s):\n")
        
        connected_sessions = []
        for i, session in enumerate(sessions):
            status_color = Colors.OKGREEN if session['status'] == 'CONNECTED' else Colors.WARNING
            print(f"{i+1}. {Colors.BOLD}Session ID:{Colors.ENDC} {session['sessionId']}")
            print(f"   {Colors.BOLD}Status:{Colors.ENDC} {status_color}{session['status']}{Colors.ENDC}")
            print(f"   {Colors.BOLD}Detail:{Colors.ENDC} {session.get('detail', 'N/A')}")
            
            if session['status'] == 'CONNECTED':
                connected_sessions.append(session)
                if session.get('token'):
                    print(f"   {Colors.BOLD}Token:{Colors.ENDC} {session['token'][:20]}...")
            print()
        
        return connected_sessions
        
    except requests.exceptions.RequestException as e:
        print_error(f"Failed to list sessions: {e}")
        return None

def create_test_session(session_id="test_session"):
    """Create a new test session"""
    print_header(f"CREATING SESSION: {session_id}")
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/sessions",
            headers={
                "Content-Type": "application/json",
                "X-Master-Key": MASTER_API_KEY
            },
            json={"sessionId": session_id}
        )
        
        if response.status_code == 201:
            data = response.json()
            print_success(f"Session created successfully!")
            print(f"{Colors.BOLD}Token:{Colors.ENDC} {data.get('token', 'N/A')}")
            return data.get('token')
        else:
            print_error(f"Failed to create session: {response.json().get('message', 'Unknown error')}")
            return None
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {e}")
        return None

def send_text_message(session_id, token, message_text):
    """Send a text message"""
    print_header("SENDING TEXT MESSAGE")
    
    print(f"{Colors.BOLD}Session ID:{Colors.ENDC} {session_id}")
    print(f"{Colors.BOLD}Recipient:{Colors.ENDC} {RECIPIENT_NUMBER}")
    print(f"{Colors.BOLD}Message:{Colors.ENDC} {message_text}\n")
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/messages?sessionId={session_id}",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json={
                "recipient_type": "individual",
                "to": RECIPIENT_NUMBER,
                "type": "text",
                "text": {"body": message_text}
            }
        )
        
        if response.status_code == 200:
            results = response.json()
            if isinstance(results, list):
                result = results[0]
            else:
                result = results
                
            if result.get('status') == 'success':
                print_success(f"Message sent successfully!")
                print(f"{Colors.BOLD}Message ID:{Colors.ENDC} {result.get('messageId', 'N/A')}")
            else:
                print_error(f"Failed to send message: {result.get('message', 'Unknown error')}")
        else:
            print_error(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {e}")

def send_image_message(session_id, token, image_url, caption):
    """Send an image message"""
    print_header("SENDING IMAGE MESSAGE")
    
    print(f"{Colors.BOLD}Session ID:{Colors.ENDC} {session_id}")
    print(f"{Colors.BOLD}Recipient:{Colors.ENDC} {RECIPIENT_NUMBER}")
    print(f"{Colors.BOLD}Image URL:{Colors.ENDC} {image_url}")
    print(f"{Colors.BOLD}Caption:{Colors.ENDC} {caption}\n")
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/messages?sessionId={session_id}",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json={
                "recipient_type": "individual",
                "to": RECIPIENT_NUMBER,
                "type": "image",
                "image": {
                    "link": image_url,
                    "caption": caption
                }
            }
        )
        
        if response.status_code == 200:
            results = response.json()
            if isinstance(results, list):
                result = results[0]
            else:
                result = results
                
            if result.get('status') == 'success':
                print_success(f"Image sent successfully!")
                print(f"{Colors.BOLD}Message ID:{Colors.ENDC} {result.get('messageId', 'N/A')}")
            else:
                print_error(f"Failed to send image: {result.get('message', 'Unknown error')}")
        else:
            print_error(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {e}")

def send_combo_message(session_id, token):
    """Send text + image + document in one request"""
    print_header("SENDING COMBO MESSAGE (Text + Image + Document)")
    
    print(f"{Colors.BOLD}Session ID:{Colors.ENDC} {session_id}")
    print(f"{Colors.BOLD}Recipient:{Colors.ENDC} {RECIPIENT_NUMBER}\n")
    
    messages = [
        {
            "recipient_type": "individual",
            "to": RECIPIENT_NUMBER,
            "type": "text",
            "text": {"body": f"🤖 Test message sent at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"}
        },
        {
            "recipient_type": "individual",
            "to": RECIPIENT_NUMBER,
            "type": "image",
            "image": {
                "link": "https://picsum.photos/400/300",
                "caption": "Random test image from Lorem Picsum"
            }
        },
        {
            "recipient_type": "individual",
            "to": RECIPIENT_NUMBER,
            "type": "document",
            "document": {
                "link": "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
                "mimetype": "application/pdf",
                "filename": "test_document.pdf"
            }
        }
    ]
    
    try:
        response = requests.post(
            f"{API_BASE_URL}/messages?sessionId={session_id}",
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            },
            json=messages
        )
        
        if response.status_code == 200:
            results = response.json()
            print(f"Sent {len(messages)} messages:\n")
            
            for i, result in enumerate(results):
                msg_type = messages[i]['type']
                if result.get('status') == 'success':
                    print_success(f"{msg_type.upper()} message sent! ID: {result.get('messageId', 'N/A')}")
                else:
                    print_error(f"{msg_type.upper()} failed: {result.get('message', 'Unknown error')}")
        else:
            print_error(f"HTTP Error {response.status_code}: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {e}")

def main():
    print_header("WHATSAPP API TEST SCRIPT")
    print_info(f"API Base URL: {API_BASE_URL}")
    print_info(f"Target Number: {RECIPIENT_NUMBER}")
    
    # List existing sessions
    connected_sessions = list_sessions()
    
    if not connected_sessions:
        print_warning("\nNo connected sessions found!")
        print_info("Please scan the QR code in the admin dashboard to connect a session.")
        print_info("Dashboard URL: http://localhost:3000/admin")
        print_info("Default password: ChangeMe123!")
        sys.exit(1)
    
    # Select a session
    print("\n" + "="*60)
    print("Select a connected session to use:")
    for i, session in enumerate(connected_sessions):
        print(f"{i+1}. {session['sessionId']}")
    
    try:
        choice = input(f"\nEnter choice (1-{len(connected_sessions)}): ")
        session_index = int(choice) - 1
        
        if 0 <= session_index < len(connected_sessions):
            selected_session = connected_sessions[session_index]
            session_id = selected_session['sessionId']
            token = selected_session.get('token')
            
            if not token:
                print_error("Selected session has no token!")
                sys.exit(1)
                
            print_success(f"\nUsing session: {session_id}")
            
            # Test menu
            while True:
                print("\n" + "="*60)
                print("SELECT TEST TO RUN:")
                print("1. Send Text Message")
                print("2. Send Image Message")
                print("3. Send Combo (Text + Image + Document)")
                print("4. Send All Tests")
                print("5. Exit")
                
                test_choice = input("\nEnter choice (1-5): ")
                
                if test_choice == "1":
                    message = input("\nEnter text message (or press Enter for default): ")
                    if not message:
                        message = f"🤖 Test message from Python script at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    send_text_message(session_id, token, message)
                    
                elif test_choice == "2":
                    image_url = input("\nEnter image URL (or press Enter for default): ")
                    if not image_url:
                        image_url = "https://picsum.photos/400/300"
                    caption = input("Enter caption (or press Enter for default): ")
                    if not caption:
                        caption = f"Test image sent at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    send_image_message(session_id, token, image_url, caption)
                    
                elif test_choice == "3":
                    send_combo_message(session_id, token)
                    
                elif test_choice == "4":
                    # Run all tests
                    send_text_message(session_id, token, f"🤖 Test 1: Text message at {datetime.now().strftime('%H:%M:%S')}")
                    input("\nPress Enter to continue to next test...")
                    
                    send_image_message(session_id, token, "https://picsum.photos/400/300", "Test 2: Image with caption")
                    input("\nPress Enter to continue to next test...")
                    
                    send_combo_message(session_id, token)
                    
                elif test_choice == "5":
                    print("\nExiting...")
                    break
                    
                else:
                    print_error("Invalid choice!")
                
                input("\nPress Enter to continue...")
                
        else:
            print_error("Invalid session choice!")
            
    except (ValueError, KeyboardInterrupt):
        print("\n\nExiting...")
        sys.exit(0)

if __name__ == "__main__":
    main() 